// Agregar productos a la tabla, eliminar y actualizar
const form = document.getElementById("product-form");
const productList = document.getElementById("product-list");

form.addEventListener("submit", function (e) {
    e.preventDefault();

    // Se obtienen los valores del formulario
    const id = document.getElementById("id").value;
    const name = document.getElementById("name").value;
    const price = document.getElementById("price").value;
    const quantity = document.getElementById("quantity").value;
    const description = document.getElementById("description").value;
    const category = document.getElementById("category").value;

    // Validacion de los campos
    if (!isValidPrice(price)) {
        alert("El precio unitario no es válido. Debe ser un número mayor a cero.");
        return;
    }

    // Filas de las tablas
    const newRow = document.createElement("tr");
    newRow.innerHTML = `
        <td>${id}</td>
        <td>${name}</td>
        <td>${price}</td>
        <td>${quantity}</td>
        <td>${description}</td>
        <td>${category}</td>
        <td>
            <button class="btn btn-danger" onclick="deleteRow(this)">Eliminar</button>
            <button class="btn btn-info" onclick="editRow(this)">Editar</button>
        </td>
    `;
    productList.appendChild(newRow);

    // Limpia el formulario
    form.reset();
});

function isValidPrice(price) {
    const regex = /^\d+(\.\d{1,2})?$/;
    return regex.test(price) && parseFloat(price) > 0;
}

// Función para eliminar una fila de la tabla
function deleteRow(button) {
    if (confirm("¿Estás seguro de que deseas eliminar este producto?")) {
        const row = button.parentNode.parentNode;
        row.remove();
    }
}

// Función para editar una fila de la tabla
function editRow(button) {
    const row = button.parentNode.parentNode;
    const cells = row.getElementsByTagName("td");

    // Se obtienen los valores de la fila
    const id = cells[0].textContent;
    const name = cells[1].textContent;
    const price = cells[2].textContent;
    const quantity = cells[3].textContent;
    const description = cells[4].textContent;
    const category = cells[5].textContent;

    // Rellenar el formulario con los valores para edición
    document.getElementById("id").value = id;
    document.getElementById("name").value = name;
    document.getElementById("price").value = price;
    document.getElementById("quantity").value = quantity;
    document.getElementById("description").value = description;
    document.getElementById("category").value = category;

    // Eliminar la fila
    row.remove();
}
